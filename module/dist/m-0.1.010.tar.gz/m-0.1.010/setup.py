from distutils.core import setup

setup(
    name = 'm',
    version = '0.1.010',
    description = 'test for module',
    author = 'corgi',
    author_email = ' ',
    package_dir = {'': r'F:\chcharmproject\study\venv'},
    packages = ['m', 'm.x']
)